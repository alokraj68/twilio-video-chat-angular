export interface Payout {
    amount: number;
    currency: string;
    eventId: number;
}
