export interface Biling {
    createdAt:	number;
    updatedAt:	number;
    eventPrice:	number;
    withdrawnAmount:	number;
    withdrwalRequest:	number;
    previousWithdrwalRequest:	number;
    balance:	number;
    status:	string;
}
