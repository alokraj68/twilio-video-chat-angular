export interface TwilioToken {
    eventId: number;
    userId: number;
    twilioToken: string;
}
