import {Rooms} from './rooms';

export interface RoomData {
    week: string;
    events: Rooms[];
}
