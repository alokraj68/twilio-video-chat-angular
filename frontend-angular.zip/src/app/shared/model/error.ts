export interface Error {
    status: string;
    error: string;
}
