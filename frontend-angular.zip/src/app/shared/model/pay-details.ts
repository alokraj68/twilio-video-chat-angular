export interface PayDetails {
    paymentEmail: string;
    currency: number;
    countryCode: string;
    mobileNumber: string;
}
