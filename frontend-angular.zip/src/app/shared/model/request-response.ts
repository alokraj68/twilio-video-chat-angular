export interface RequestResponse {
    payload: {};
    accessToken: string;
}
