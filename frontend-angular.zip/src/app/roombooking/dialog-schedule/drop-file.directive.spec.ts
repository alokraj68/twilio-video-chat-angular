import { DropFileDirective } from './drop-file.directive';

describe('DropFileDirective', () => {
  it('should create an instance', () => {
    const directive = new DropFileDirective();
    expect(directive).toBeTruthy();
  });
});
