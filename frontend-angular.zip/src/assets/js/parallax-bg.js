$(document).ready(function(){
	//Home Image Slider
	$.backstretch([
	  "assets/images/bg1.jpg",
	  "assets/images/bg2.jpg",
	  "assets/images/bg3.jpeg"
	], {duration: 4500, fade: 'slow'});

});
